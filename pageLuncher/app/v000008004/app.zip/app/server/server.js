// 初始化转换数据
let data = location.search.replace("?data=", "");
data = decodeURIComponent(data);
data = JSON.parse(data);
let {
    type,
    dirpath
} = data;
let {
    remote
} = require('electron');

let currentWin = remote.getCurrentWindow();

const {
    BrowserWindow,
    dialog
} = remote;

(async () => {
    switch (type) {
        case "page":
            try {
                // 创建服务器
                let createServer = require("./page/main");
                let {
                    pageServerUtil
                } = await createServer(dirpath);

                // 创建浏览器窗口。
                let win = new BrowserWindow({
                    width: 1280,
                    height: 720,
                    backgroundColor: "#303336",
                    frame: false,
                    titleBarStyle: 'hiddenInset',
                    // webPreferences: {
                    //     nodeIntegration: false
                    // }
                })

                // 然后加载应用的 index.html。
                win.loadURL('http://localhost:8803/pageCreator/index.html');

                // win.webContents.openDevTools();

                win.on('closed', async () => {
                    win = null
                    if (currentWin) {
                        // 等待保存成功再退出
                        await pageServerUtil.saveData();

                        currentWin.close();
                        currentWin = null;
                    }
                })

                currentWin.on('closed', () => {
                    currentWin = null;
                    if (win) {
                        win.close();
                        win = null;
                    }
                });
            } catch (e) {
                // alert('项目文件受损');
                dialog.showMessageBox({
                    title: '打开出错',
                    type: 'error',
                    message: '项目文件受损'
                });
                currentWin.close();
            }
            break;
    }

    console.log(data);
})();