let {
    // 初始化Source服务器
    initSourceServer
} = require('./sourceServer');

let {
    initPageServer
} = require('./pageServer');

// 引入服务器模块
const PieServer = require('pieServer');
const path = require("path");

let lunchData = JSON.parse(localStorage.getItem("_launcher_data"));

// 运行目录地址
// debugger
let pageCreatorDir = path.normalize(lunchData.page.dir);
// let pageCreatorDir = '/Users/huangyao/Documents/GitHub/PageCreator';
// let pageCreatorDir = path.normalize(__dirname + '/../../application/PageCreator');

console.log(pageCreatorDir);

// 暴露初始化方法
module.exports = (projectDir) => {
    // 项目目录地址
    // let projectDir;

    // 生成服务器测试
    var app = new PieServer();

    // 设置映射图片目录
    app.dirMap.set("$", projectDir + "/source");
    // app.dirMap.set("$$", projectDir);
    app.dirMap.set("pageCreator", pageCreatorDir);

    // 设置资源（图片）服务器
    initSourceServer({
        app,
        projectDir
    });

    // 设置page项目服务器
    initPageServer({
        app,
        projectDir
    });

    // 接口
    let listen = 8803;

    // 设置监听端口
    app.listen(listen);

    return app;
}