const crypto = require('crypto');

let key = '751f621ea5c8f930';
let iv = '2624750004598718';

const encrypt = function (data) {
    let cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
    let crypted = cipher.update(data, 'utf8', 'binary');
    crypted += cipher.final('binary');
    crypted = Buffer.from(crypted, 'binary').toString('base64');
    return crypted;
};

const decrypt = function (crypted) {
    let decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
    crypted = Buffer.from(crypted, 'base64').toString('binary');
    let decoded = decipher.update(crypted, 'binary', 'utf8');
    decoded += decipher.final('utf8');
    return decoded;
};

// setTimeout(() => {
//     let data = "Hello, nodejs. 演示aes-128-cbc加密和解密";
//     console.log("需要加密的数据:", data);
//     let crypted = encrypt(data);
//     console.log("数据加密后:", crypted);
//     let dec = decrypt(crypted);
//     console.log("数据解密后:", dec);
// }, 3000);

const setBgAttrs = (p, data) => {
    // 其他关键属性
    ["background-color", "background-image", "background-size", "background-repeat", "background-position"].forEach(k => {
        let val = p[k];

        if (val) {
            if (k === "background-image" && /^\/\$/.test(val)) {
                val = val.replace(/^\/\$/, "../source");
            }

            // 修正属性
            data[k] = val;
        }
    });
}

exports.encrypt = encrypt;
exports.decrypt = decrypt;

// 生成pageRunner的数据
exports.createPageRunnerData = (data, animationData) => {
    let {
        mainPage,
    } = data;

    let mPage = {};
    let animation = [];
    let sdata = {
        animation,
        mainPage: mPage
    };

    // 动画寄存对象
    let animeInSet = new Set();
    let animeOutSet = new Set();

    mainPage.forEach((p, i) => {
        let pageData = {
            tag: "page",
            pageIn: p.pageIn,
            pageOut: p.pageOut
        };
        mPage[i] = pageData;

        setBgAttrs(p, pageData);

        // 添加动画库
        animeInSet.add(p.pageIn);
        animeOutSet.add(p.pageOut);

        // 设置元素
        p.forEach((e, i) => {
            let eleData = e.object;
            delete eleData.xvele;
            pageData[i] = eleData;

            // 修正图片属性
            setBgAttrs(e, eleData);

            switch (e.tag) {
                case "p-text":
                    eleData.tag = "text";
                    break;
                case "p-pic":
                    eleData.tag = "pic";

                    if (eleData.picUrl && /^\/\$/.test(eleData.picUrl)) {
                        eleData.picUrl = eleData.picUrl.replace(/^\/\$/, "../source");
                    }
                    break;
            }

            // 添加动画库
            animeInSet.add(e.animateIn);
            animeOutSet.add(e.animateOut);
        });
    });

    animeInSet.forEach(name => {
        if (name) {
            animationData.animateIn.some(animeData => {
                if (animeData.animateId === name) {
                    if (animeData.frame) {
                        animation.push({
                            type: "animeIn",
                            name,
                            frame: animeData.frame.object,
                            css: animeData.css
                        });
                    } else {
                        animation.push({
                            type: "animeIn",
                            name,
                            animation: animeData.animation.object,
                            css: animeData.css
                        });
                    }
                    return true;
                }
            });
        }
    });

    animeOutSet.forEach(name => {
        if (name) {
            animationData.animateOut.some(animeData => {
                if (animeData.animateId === name) {
                    animation.push({
                        type: "animeOut",
                        name,
                        frame: animeData.frame.object,
                        css: animeData.css
                    });
                    return true;
                }
            });
        }
    });

    return sdata;
}