drill.define(async (load) => {
    // 将主数据获取返回
    let pdata = await window.pdata;

    return pdata;
});