// 初始化转换数据
let data = location.search.replace("?data=", "");
data = decodeURIComponent(data);
data = JSON.parse(data);
let {
    type,
    dirpath
} = data;
let {
    remote
} = require('electron');

let currentWin = remote.getCurrentWindow();

const {
    BrowserWindow,
} = remote;

switch (type) {
    case "page":
        // 创建服务器
        let createServer = require("./page/main");
        createServer(dirpath);

        // 创建浏览器窗口。
        // let win = new BrowserWindow({
        //     width: 1280,
        //     height: 720,
        //     backgroundColor: "#303336",
        //     frame: false,
        //     titleBarStyle: 'hiddenInset',
        //     // webPreferences: {
        //     //     nodeIntegration: false
        //     // }
        // })

        // // 然后加载应用的 index.html。
        // win.loadURL('http://localhost:8803/pageCreator/index.html');

        // win.webContents.openDevTools();

        // win.on('closed', () => {
        //     win = null
        //     if (currentWin) {
        //         currentWin.close();
        //         currentWin = null;
        //     }
        // })

        // currentWin.on('closed', () => {
        //     currentWin = null;
        //     if (win) {
        //         win.close();
        //         win = null;
        //     }
        // });
        break;
}

console.log(data);