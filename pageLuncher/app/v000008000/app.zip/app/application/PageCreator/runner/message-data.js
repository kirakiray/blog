(function () {
    window.pdata = new Promise((res, rej) => {
        window.addEventListener("message", function (e) {
            res(e.data);
        });
    });
})();