const pfs = require("pfs");
const http = require('http');
const WebSocket = require('faye-websocket');
const os = require('os');
const {
    stanz
} = require('stanz');

const urltool = require('url');
const querystring = require("querystring");
const pageServerUtil = require("./pageServerUtil");

// 获取ipv4地址
let ipv4 = "";

// 查看ip地址逻辑
const nfs = os.networkInterfaces();
Object.values(nfs).forEach(arr => {
    arr.forEach(function (e) {
        if (e.family == 'IPv4' && /^192\./.test(e.address)) {
            ipv4 = e.address;
        }
    });
});

// 添加runAnime
const addRunAnimeAttr = e => {
    e.runAnime = 0;
    e.runOutAnime = 0;
};

// 删除runAnime
const removeUnneedAttr = (e) => {
    delete e.runAnime;
    delete e.runOutAnime;
};

const jsonToStr = data => {
    let redata = pageServerUtil.encrypt(JSON.stringify(data));
    return redata;
    // return JSON.stringify(data);
}

const strToJson = data => {
    let redata = JSON.parse(pageServerUtil.decrypt(data));
    return redata;
    // return JSON.parse(data);
}

// 暴露初始化函数
exports.initPageServer = async ({
    app,
    projectDir
}) => {
    // 获取文件
    let project = await pfs.readFile(projectDir + "/page.json");

    // 转换成stanz对象
    project = stanz(JSON.parse(project.toString()));

    // 将page和page的所有元素添runAnime属性
    project.mainPage.forEach(e => {
        addRunAnimeAttr(e);
        e.forEach(e2 => {
            addRunAnimeAttr(e2);
        });
    });

    // 生成公用数据
    let commonData = stanz({
        // 项目地址
        projectDir,
        // 页面数据
        project,
        // 所有分身
        splits: [],
        // 分屏的链接
        splitAddress: `http://${ipv4}:8803/pageCreator/split.html`,
        // 动画数据，需要客户端渲染
        animationData: ""
    });

    // 寄存器
    let pageWSMap = new Set();
    let writeTimer;
    // 页面数据有改动就保存(写入)文件
    const saveData = async () => {
        // 写入前去掉runAnime
        let cloneProject = commonData.project.clone();
        cloneProject.mainPage.forEach(e => {
            removeUnneedAttr(e);

            // 删除缩略图
            delete e.thumbnail;

            e.forEach(e2 => {
                removeUnneedAttr(e2);
            });
        });

        // 写入项目json
        await pfs.writeFile(projectDir + "/page.json", cloneProject.string, "utf-8");

        // 写入runner data
        // let runnerData = pageServerUtil.createPageRunnerData(cloneProject, commonData.animationData);
        // pfs.writeFile(projectDir + "/pageRunner/data.js", `define(${JSON.stringify(runnerData)})`, "utf-8");

        // 发送保存成功
        pageWSMap.forEach(e => {
            e.ws.send(jsonToStr({
                type: "saveok"
            }));
        });

        return 1;
    }

    commonData.watch("project", e => {
        clearTimeout(writeTimer);
        writeTimer = setTimeout(() => {
            saveData();
        }, 2500);
    });

    // source数据更新，发送给各个端
    commonData.on('update', e => {
        let {
            trend
        } = e;

        pageWSMap.forEach(e => {
            e.ws.send(jsonToStr({
                type: "update",
                trend
            }));
        });
    });

    // 创建websocket服务器
    let server = http.createServer();

    server.on('upgrade', function (request, socket, body) {
        if (WebSocket.isWebSocket(request)) {
            // 转换成url对象，方便后续操作
            let urlObj = urltool.parse(request.url);
            let queryData = querystring.parse(urlObj.query);

            // 建立socket
            let ws = new WebSocket(request, socket, body);

            // 目标数据对象
            let tarObj = {
                ws
            };

            // 添加进寄存器
            pageWSMap.add(tarObj);

            // 放入分身数据
            if (queryData) {
                let {
                    aid
                } = queryData;

                // 挂载分身id
                tarObj.aid = aid;
            }

            // 数据初始接通
            ws.on('open', function (event) {
                // 发送初始化数据
                ws.send(jsonToStr({
                    type: "start",
                    data: commonData.object
                }));
            });

            // 数据接通
            ws.on('message', function (event) {
                // 获取更新数据
                let d = strToJson(event.data);
                switch (d.type) {
                    case "update":
                        // 自身数据同步
                        commonData.entrend(d.trend);
                        break;
                    case "ping":
                        ws.send(jsonToStr({
                            type: "pong"
                        }));
                        break;
                }
            });

            // 数据清仓
            ws.on('close', function (event) {
                console.log('close', event.code, event.reason);

                // 查找并删除相应的splits对象
                let splitsId = commonData.splits.findIndex(e => e.aid === tarObj.aid);
                if (splitsId > -1) {
                    commonData.splits.splice(splitsId, 1);
                }

                pageWSMap.delete(tarObj);
                tarObj.ws = null;
                tarObj = null;
                ws = null;
            });
        }
    });

    server.listen(8005);

    return {
        saveData
    };
}