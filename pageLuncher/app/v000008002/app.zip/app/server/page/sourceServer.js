let pfs = require("pfs");
const http = require('http');
const WebSocket = require('faye-websocket');
const {
    stanz
} = require('stanz');

// 初始化source服务器接口
exports.initSourceServer = async ({
    app,
    projectDir
}) => {
    // 设置上传图片接口
    app.connector.set("/uploadSource", async (e) => {
        // 将图片保存到本地，并更新对象
        let {
            data
        } = e;

        // 获取文件后缀名
        let houzhui = data.name.match(/.+(\..+$)/)

        let filePathName = "img_" + new Date().getTime() + houzhui[1];
        let filepath = projectDir + "/source/" + filePathName;

        // 写入文件
        await pfs.writeFile(filepath, data.file);

        // 添加数据
        sourceData.pics.push({
            "tag": "source-block",
            "xvele": 1,
            // 去掉后缀的名字
            "name": data.name.replace(/(.+)\..+/, "$1"),
            "path": "/$/" + filePathName,
            "tagid": []
        });

        return JSON.stringify({
            stat: 1,
            desc: "upload ok"
        });
    });

    // 获取文件
    let sourceData = await pfs.readFile(projectDir + "/source.json");

    // 转换成stanz对象
    sourceData = stanz(JSON.parse(sourceData.toString()));

    // 有改动就保存(写入)文件
    let writeTimer;
    sourceData.watch(e => {
        clearTimeout(writeTimer);
        writeTimer = setTimeout(() => {
            pfs.writeFile(projectDir + "/source.json", sourceData.string, "utf-8");
        }, 1000);
    });

    // source数据更新，发送给各个端
    sourceData.on('update', e => {
        let {
            trend
        } = e;

        sourceWSMap.forEach(e => {
            e.send(JSON.stringify({
                type: "update",
                trend
            }));
        });
    });

    // 创建websocket服务器
    let server = http.createServer();

    // 寄存器
    let sourceWSMap = new Set();

    server.on('upgrade', function (request, socket, body) {
        if (WebSocket.isWebSocket(request)) {
            // 建立socket
            let ws = new WebSocket(request, socket, body);

            // 添加进寄存器
            sourceWSMap.add(ws);

            // 数据初始接通
            ws.on('open', function (event) {
                // 发送初始化数据
                ws.send(JSON.stringify({
                    type: "start",
                    data: sourceData.object
                }));
            });

            // 数据接通
            ws.on('message', function (event) {
                // 获取更新数据
                let d = JSON.parse(event.data);
                switch (d.type) {
                    case "update":
                        // 自身数据同步
                        sourceData.entrend(d.trend);
                        break;
                    case "ping":
                        ws.send(JSON.stringify({
                            type: "pong"
                        }));
                        break;
                }
            });

            // 数据清仓
            ws.on('close', function (event) {
                console.log('close', event.code, event.reason);
                sourceWSMap.delete(ws);
                ws = null;
            });
        }
    });

    server.listen(8000);
}